
**Data Description**
The dataset folder contains the following:
train.csv: (30000, 24)
test.csv: (20000, 23)

